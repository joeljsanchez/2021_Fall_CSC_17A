/* 
 * Name: Joel Sanchez
 * Assignment: Hello World!
 * Class: CSC-17A Fall 2021
 * Instructor: Dr. Lehr
 * Date: September 6th, 2021
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
        
    cout << "Hello World!" << endl; 
    
    return 0;
}

